package com.quiko.app;

public class Reminder {
    public long id;
    public String task;
    public long triggerTimeMs;
    public boolean done;

    public Reminder(long id, String task, long triggerTimeMs, boolean done) {
        this.id = id;
        this.task = task;
        this.triggerTimeMs = triggerTimeMs;
        this.done = done;
    }
}

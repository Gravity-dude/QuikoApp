package com.quiko.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * VoiceListenerService
 * ─────────────────────
 * Runs as a foreground service and continuously listens for
 * the wake word "Hey Quiko" using Android's offline SpeechRecognizer.
 *
 * After the wake word is detected it plays a confirmation beep,
 * then starts a second recognition pass to capture the actual command.
 */
public class VoiceListenerService extends Service {

    private static final String TAG = "VoiceListenerService";
    private static final String CHANNEL_ID = "quiko_channel";
    private static final int NOTIF_ID = 1;

    // ── Wake-word variants we accept ─────────────────────────────────────
    private static final String[] WAKE_WORDS = {
            "hey quiko", "hey quicko", "hey quick o", "quiko", "hey kiko"
    };

    // ── State machine ─────────────────────────────────────────────────────
    private enum State { IDLE, WAKE_LISTENING, COMMAND_LISTENING }
    private State currentState = State.IDLE;

    private SpeechRecognizer speechRecognizer;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private CommandProcessor commandProcessor;
    private boolean serviceRunning = false;

    // ── Callback to push UI updates to MainActivity ───────────────────────
    public interface StatusCallback {
        void onUpdate(String status, String lastCommand);
    }
    private static StatusCallback statusCallback;
    public static void setStatusCallback(StatusCallback cb) { statusCallback = cb; }

    // ─────────────────────────────────────────────────────────────────────
    @Override
    public void onCreate() {
        super.onCreate();
        commandProcessor = new CommandProcessor(this);
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopListening();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(NOTIF_ID, buildNotification("👂 Listening for \"Hey Quiko\"..."));
        serviceRunning = true;
        initSpeechRecognizer();
        startWakeWordListening();
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ─────────────────────────────────────────────────────────────────────
    // SpeechRecognizer setup
    // ─────────────────────────────────────────────────────────────────────
    private void initSpeechRecognizer() {
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new QuikoRecognitionListener());
    }

    private Intent buildRecognitionIntent(boolean preferOffline) {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-US");
        i.putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_MODEL_RESULTS, true);
        // KEY: force offline recognition
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 500L);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L);
        return i;
    }

    // ─────────────────────────────────────────────────────────────────────
    // State transitions
    // ─────────────────────────────────────────────────────────────────────
    private void startWakeWordListening() {
        if (!serviceRunning) return;
        currentState = State.WAKE_LISTENING;
        updateNotification("👂 Listening for \"Hey Quiko\"...");
        updateStatus("👂 Listening for \"Hey Quiko\"...", null);
        handler.postDelayed(() -> {
            if (serviceRunning && speechRecognizer != null && currentState == State.WAKE_LISTENING) {
                speechRecognizer.startListening(buildRecognitionIntent(true));
            }
        }, 300);
    }

    private void startCommandListening() {
        if (!serviceRunning) return;
        currentState = State.COMMAND_LISTENING;
        updateNotification("🎙 Listening for command...");
        updateStatus("✅ Hey Quiko! 🎙 Speak your command...", null);
        SoundHelper.playActivationBeep(this);

        // Reinit to avoid stale state
        initSpeechRecognizer();
        handler.postDelayed(() -> {
            if (serviceRunning && speechRecognizer != null) {
                speechRecognizer.startListening(buildRecognitionIntent(true));
            }
        }, 600);
    }

    private void stopListening() {
        serviceRunning = false;
        if (speechRecognizer != null) {
            speechRecognizer.stopListening();
            speechRecognizer.cancel();
            speechRecognizer.destroy();
            speechRecognizer = null;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Recognition Listener
    // ─────────────────────────────────────────────────────────────────────
    private class QuikoRecognitionListener implements RecognitionListener {

        @Override public void onReadyForSpeech(Bundle params) {}
        @Override public void onBeginningOfSpeech() {}
        @Override public void onRmsChanged(float rmsdB) {}
        @Override public void onBufferReceived(byte[] buffer) {}
        @Override public void onPartialResults(Bundle partialResults) {
            // Check partial results for wake word for faster response
            if (currentState == State.WAKE_LISTENING) {
                ArrayList<String> partial = partialResults.getStringArrayList(
                        SpeechRecognizer.RESULTS_RECOGNITION);
                if (partial != null) {
                    for (String text : partial) {
                        if (containsWakeWord(text.toLowerCase())) {
                            speechRecognizer.cancel();
                            startCommandListening();
                            return;
                        }
                    }
                }
            }
        }

        @Override
        public void onResults(Bundle results) {
            ArrayList<String> matches = results.getStringArrayList(
                    SpeechRecognizer.RESULTS_RECOGNITION);
            if (matches == null || matches.isEmpty()) {
                restartCurrentState();
                return;
            }

            String topResult = matches.get(0).toLowerCase().trim();
            Log.d(TAG, "State=" + currentState + " Result='" + topResult + "'");

            if (currentState == State.WAKE_LISTENING) {
                if (containsWakeWord(topResult)) {
                    startCommandListening();
                } else {
                    restartCurrentState();
                }
            } else if (currentState == State.COMMAND_LISTENING) {
                processCommand(topResult, matches);
            }
        }

        @Override
        public void onError(int error) {
            Log.w(TAG, "SpeechRecognizer error: " + error);
            // Restart after short delay on most errors
            handler.postDelayed(() -> {
                if (serviceRunning) {
                    initSpeechRecognizer();
                    startWakeWordListening();
                }
            }, 1000);
        }

        @Override public void onEndOfSpeech() {}
        @Override public void onEvent(int eventType, Bundle params) {}
    }

    // ─────────────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────────────
    private boolean containsWakeWord(String text) {
        for (String ww : WAKE_WORDS) {
            if (text.contains(ww)) return true;
        }
        return false;
    }

    private void processCommand(String command, List<String> allResults) {
        // Strip wake word if it leaked into the command pass
        for (String ww : WAKE_WORDS) {
            command = command.replace(ww, "").trim();
        }
        if (command.isEmpty() && allResults.size() > 1) {
            command = allResults.get(1).toLowerCase().trim();
        }

        Log.d(TAG, "Processing command: " + command);
        String feedback = commandProcessor.process(command);
        updateStatus("💬 \"" + command + "\" → " + feedback, command);
        updateNotification("Last: " + command);

        // Return to wake-word listening after command
        handler.postDelayed(this::startWakeWordListening, 1500);
    }

    private void restartCurrentState() {
        handler.postDelayed(() -> {
            if (serviceRunning) {
                if (currentState == State.WAKE_LISTENING) {
                    startWakeWordListening();
                } else {
                    startWakeWordListening();
                }
            }
        }, 400);
    }

    // ─────────────────────────────────────────────────────────────────────
    // Notification helpers
    // ─────────────────────────────────────────────────────────────────────
    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Quiko Voice Assistant",
                NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Quiko is listening for your voice commands");
        channel.setShowBadge(false);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(channel);
    }

    private Notification buildNotification(String text) {
        Intent mainIntent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, mainIntent,
                PendingIntent.FLAG_IMMUTABLE);

        Intent stopIntent = new Intent(this, VoiceListenerService.class);
        stopIntent.setAction("STOP");
        PendingIntent stopPi = PendingIntent.getService(this, 1, stopIntent,
                PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Quiko Assistant")
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_quiko)
                .setContentIntent(pi)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .addAction(android.R.drawable.ic_delete, "Stop", stopPi)
                .build();
    }

    private void updateNotification(String text) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(NOTIF_ID, buildNotification(text));
    }

    private void updateStatus(String status, String lastCmd) {
        if (statusCallback != null) {
            statusCallback.onUpdate(status, lastCmd);
        }
    }

    @Override
    public void onDestroy() {
        stopListening();
        super.onDestroy();
    }
}

package com.quiko.app;

import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ReminderAdapter extends RecyclerView.Adapter<ReminderAdapter.VH> {

    interface OnDeleteListener { void onDelete(Reminder r); }

    private List<Reminder> items;
    private final OnDeleteListener deleteListener;
    private final SimpleDateFormat sdf = new SimpleDateFormat("MMM d, h:mm a", Locale.US);

    public ReminderAdapter(List<Reminder> items, OnDeleteListener l) {
        this.items = items;
        this.deleteListener = l;
    }

    public void updateData(List<Reminder> newItems) {
        this.items = newItems;
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_reminder, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        Reminder r = items.get(position);
        holder.tvTask.setText(r.task);
        holder.tvTime.setText(sdf.format(new Date(r.triggerTimeMs)));
        if (r.done) {
            holder.tvTask.setPaintFlags(holder.tvTask.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            holder.tvTask.setAlpha(0.5f);
        } else {
            holder.tvTask.setPaintFlags(holder.tvTask.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
            holder.tvTask.setAlpha(1.0f);
        }
        holder.btnDelete.setOnClickListener(v -> deleteListener.onDelete(r));
    }

    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvTask, tvTime;
        ImageButton btnDelete;
        VH(@NonNull View itemView) {
            super(itemView);
            tvTask    = itemView.findViewById(R.id.tvTask);
            tvTime    = itemView.findViewById(R.id.tvTime);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}

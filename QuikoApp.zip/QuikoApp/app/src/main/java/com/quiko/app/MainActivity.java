package com.quiko.app;

import android.Manifest;
import android.app.AlarmManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 101;
    private TextView tvStatus;
    private TextView tvLastCommand;
    private SwitchMaterial switchListening;
    private RecyclerView rvReminders;
    private ReminderAdapter reminderAdapter;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        initViews();
        checkPermissions();
        loadReminders();
    }

    private void initViews() {
        tvStatus = findViewById(R.id.tvStatus);
        tvLastCommand = findViewById(R.id.tvLastCommand);
        switchListening = findViewById(R.id.switchListening);
        rvReminders = findViewById(R.id.rvReminders);

        rvReminders.setLayoutManager(new LinearLayoutManager(this));

        switchListening.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                startVoiceService();
            } else {
                stopVoiceService();
            }
        });

        FloatingActionButton fabClear = findViewById(R.id.fabClear);
        fabClear.setOnClickListener(v -> showClearRemindersDialog());

        // Listen for status updates from service
        VoiceListenerService.setStatusCallback((status, lastCmd) -> {
            runOnUiThread(() -> {
                if (status != null) tvStatus.setText(status);
                if (lastCmd != null) {
                    tvLastCommand.setText("Last: " + lastCmd);
                    loadReminders();
                }
            });
        });
    }

    private void startVoiceService() {
        if (!hasRequiredPermissions()) {
            switchListening.setChecked(false);
            requestPermissions();
            return;
        }
        Intent serviceIntent = new Intent(this, VoiceListenerService.class);
        serviceIntent.setAction("START");
        ContextCompat.startForegroundService(this, serviceIntent);
        tvStatus.setText("👂 Listening for \"Hey Quiko\"...");
    }

    private void stopVoiceService() {
        Intent serviceIntent = new Intent(this, VoiceListenerService.class);
        serviceIntent.setAction("STOP");
        startService(serviceIntent);
        tvStatus.setText("⏸ Paused — Toggle to resume");
    }

    private void loadReminders() {
        List<Reminder> reminders = dbHelper.getAllReminders();
        if (reminderAdapter == null) {
            reminderAdapter = new ReminderAdapter(reminders, reminder -> {
                dbHelper.deleteReminder(reminder.id);
                loadReminders();
            });
            rvReminders.setAdapter(reminderAdapter);
        } else {
            reminderAdapter.updateData(reminders);
        }
    }

    private void showClearRemindersDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Clear All Reminders")
                .setMessage("Delete all saved reminders?")
                .setPositiveButton("Yes", (d, w) -> {
                    dbHelper.deleteAllReminders();
                    loadReminders();
                    Toast.makeText(this, "Reminders cleared", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("No", null)
                .show();
    }

    private boolean hasRequiredPermissions() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void checkPermissions() {
        if (!hasRequiredPermissions()) {
            requestPermissions();
        } else {
            // Auto-start service on launch
            switchListening.setChecked(true);
        }
    }

    private void requestPermissions() {
        String[] perms = {Manifest.permission.RECORD_AUDIO};
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms = new String[]{
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.POST_NOTIFICATIONS
            };
        }
        ActivityCompat.requestPermissions(this, perms, PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            if (allGranted) {
                switchListening.setChecked(true);
            } else {
                Toast.makeText(this,
                        "Microphone permission is required for Hey Quiko to work",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadReminders();
        VoiceListenerService.setStatusCallback((status, lastCmd) -> {
            runOnUiThread(() -> {
                if (status != null) tvStatus.setText(status);
                if (lastCmd != null) {
                    tvLastCommand.setText("Last: " + lastCmd);
                    loadReminders();
                }
            });
        });

        // Check exact alarm permission on Android 12+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (!alarmManager.canScheduleExactAlarms()) {
                new AlertDialog.Builder(this)
                        .setTitle("Exact Alarms Permission")
                        .setMessage("Quiko needs exact alarm permission for alarms to fire precisely. Grant it in Settings?")
                        .setPositiveButton("Open Settings", (d, w) -> {
                            Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                            startActivity(intent);
                        })
                        .setNegativeButton("Skip", null)
                        .show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        VoiceListenerService.setStatusCallback(null);
    }
}

package com.quiko.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Vibrator;
import android.os.VibrationEffect;

import androidx.core.app.NotificationCompat;

public class ReminderReceiver extends BroadcastReceiver {

    private static final String CHANNEL_ID = "quiko_reminders";

    @Override
    public void onReceive(Context context, Intent intent) {
        String task = intent.getStringExtra("task");
        int reminderId = intent.getIntExtra("id", -1);
        if (task == null) task = "Reminder";

        // Mark reminder as done in DB
        if (reminderId != -1) {
            new DatabaseHelper(context).markReminderDone(reminderId);
        }

        createChannel(context);
        showReminderNotification(context, task, reminderId);
        vibrate(context);
    }

    private void createChannel(Context context) {
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "Quiko Reminders", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Reminder notifications");
        ch.enableVibration(true);
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(ch);
    }

    private void showReminderNotification(Context context, String task, int id) {
        Intent openApp = new Intent(context, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(context, id, openApp,
                PendingIntent.FLAG_IMMUTABLE);

        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_quiko)
                .setContentTitle("🔔 Quiko Reminder")
                .setContentText(task)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(task))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setSound(soundUri)
                .setAutoCancel(true)
                .setContentIntent(pi);

        NotificationManager nm = context.getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(3000 + id, builder.build());
    }

    private void vibrate(Context context) {
        Vibrator v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if (v == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(400, VibrationEffect.DEFAULT_AMPLITUDE));
        } else {
            v.vibrate(400);
        }
    }
}

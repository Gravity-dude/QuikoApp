package com.quiko.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.speech.tts.TextToSpeech;
import android.util.Log;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * CommandProcessor
 * ─────────────────
 * Parses natural language voice commands and executes them.
 *
 * Supported commands:
 *   • set alarm [at] [HH:MM / H AM/PM / in X minutes/hours]
 *   • turn on/off flashlight / torch
 *   • remind me [to <task>] [at <time> / in <X> minutes/hours]
 *   • cancel alarm
 *   • what time is it
 *   • help
 */
public class CommandProcessor {

    private static final String TAG = "CommandProcessor";
    private final Context context;
    private final AlarmManager alarmManager;
    private final DatabaseHelper dbHelper;
    private TextToSpeech tts;
    private String torchCameraId;

    // Number words → digits
    private static final Map<String, Integer> NUMBER_WORDS = new HashMap<>();
    static {
        String[] ones = {"zero","one","two","three","four","five","six","seven",
                "eight","nine","ten","eleven","twelve","thirteen","fourteen",
                "fifteen","sixteen","seventeen","eighteen","nineteen"};
        String[] tens = {"","","twenty","thirty","forty","fifty"};
        for (int i = 0; i < ones.length; i++) NUMBER_WORDS.put(ones[i], i);
        for (int i = 2; i < tens.length; i++) NUMBER_WORDS.put(tens[i], i * 10);
    }

    public CommandProcessor(Context context) {
        this.context = context.getApplicationContext();
        this.alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        this.dbHelper = new DatabaseHelper(context);

        // Init TTS for voice feedback
        tts = new TextToSpeech(context, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.US);
            }
        });

        // Find torch camera ID
        try {
            CameraManager cm = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
            for (String id : cm.getCameraIdList()) {
                if (cm.getCameraCharacteristics(id)
                        .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE)
                        == Boolean.TRUE) {
                    torchCameraId = id;
                    break;
                }
            }
        } catch (CameraAccessException e) {
            Log.e(TAG, "Camera init error", e);
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Entry point
    // ─────────────────────────────────────────────────────────────────────
    public String process(String command) {
        command = command.trim().toLowerCase();
        Log.d(TAG, "Processing: " + command);

        if (command.isEmpty()) return "I didn't catch that.";

        // ── Alarm ────────────────────────────────────────────────────────
        if (command.contains("alarm") && command.contains("cancel")) {
            return cancelAlarm();
        }
        if (command.contains("set alarm") || command.contains("alarm") && hasTimeContext(command)) {
            return setAlarm(command);
        }

        // ── Flashlight ───────────────────────────────────────────────────
        if (command.contains("flash") || command.contains("torch") || command.contains("light")) {
            boolean on = command.contains("on") || command.contains("turn on")
                    || (!command.contains("off") && !command.contains("turn off"));
            return toggleFlashlight(on);
        }

        // ── Reminder ─────────────────────────────────────────────────────
        if (command.contains("remind") || command.contains("reminder")) {
            return setReminder(command);
        }

        // ── Time query ───────────────────────────────────────────────────
        if (command.contains("time") || command.contains("what time")) {
            return tellTime();
        }

        // ── Help ─────────────────────────────────────────────────────────
        if (command.contains("help") || command.contains("what can you do")) {
            return help();
        }

        return "Command not recognised. Try: set alarm, flashlight on, remind me, or help.";
    }

    // ─────────────────────────────────────────────────────────────────────
    // ALARM
    // ─────────────────────────────────────────────────────────────────────
    private String setAlarm(String command) {
        Calendar cal = parseTime(command);
        if (cal == null) {
            speak("Sorry, I couldn't understand the time.");
            return "❌ Couldn't parse time from: \"" + command + "\"";
        }

        // If time already passed today, schedule for tomorrow
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
            cal.add(Calendar.DAY_OF_YEAR, 1);
        }

        Intent alarmIntent = new Intent(context, AlarmReceiver.class);
        alarmIntent.setAction("com.quiko.app.ALARM_TRIGGER");
        String label = "Quiko Alarm";
        alarmIntent.putExtra("label", label);
        alarmIntent.putExtra("time", formatTime(cal));

        PendingIntent pi = PendingIntent.getBroadcast(context, (int) cal.getTimeInMillis(),
                alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
            } else {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
            }
        } catch (SecurityException e) {
            alarmManager.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
        }

        String timeStr = formatTime(cal);
        speak("Alarm set for " + timeStr);
        return "⏰ Alarm set for " + timeStr;
    }

    private String cancelAlarm() {
        Intent alarmIntent = new Intent(context, AlarmReceiver.class);
        alarmIntent.setAction("com.quiko.app.ALARM_TRIGGER");
        PendingIntent pi = PendingIntent.getBroadcast(context, 0, alarmIntent,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) {
            alarmManager.cancel(pi);
            pi.cancel();
            speak("Alarm cancelled");
            return "🚫 Alarm cancelled";
        }
        speak("No alarm found to cancel");
        return "No active alarm found";
    }

    // ─────────────────────────────────────────────────────────────────────
    // FLASHLIGHT
    // ─────────────────────────────────────────────────────────────────────
    private String toggleFlashlight(boolean on) {
        if (torchCameraId == null) return "❌ No flashlight found on this device";
        try {
            CameraManager cm = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
            cm.setTorchMode(torchCameraId, on);
            String msg = on ? "Flashlight on" : "Flashlight off";
            speak(msg);
            return (on ? "🔦 " : "⬛ ") + msg;
        } catch (CameraAccessException e) {
            Log.e(TAG, "Flashlight error", e);
            return "❌ Flashlight error: " + e.getMessage();
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // REMINDER
    // ─────────────────────────────────────────────────────────────────────
    private String setReminder(String command) {
        // Extract task text – everything after "remind me to" or "reminder"
        String task = command
                .replaceAll("(?i)hey quiko", "")
                .replaceAll("(?i)remind me to", "")
                .replaceAll("(?i)remind me", "")
                .replaceAll("(?i)set a reminder", "")
                .replaceAll("(?i)reminder", "")
                .trim();

        // Try to parse a time from the command
        Calendar cal = parseTime(command);
        long triggerAt;
        String timeDisplay;

        if (cal != null) {
            if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
                cal.add(Calendar.DAY_OF_YEAR, 1);
            }
            triggerAt = cal.getTimeInMillis();
            timeDisplay = formatTime(cal);
            // Remove time part from task label
            task = task.replaceAll("(?i)(at|in)\\s+\\d+.*", "").trim();
        } else {
            // Default: 1 hour from now
            cal = Calendar.getInstance();
            cal.add(Calendar.HOUR_OF_DAY, 1);
            triggerAt = cal.getTimeInMillis();
            timeDisplay = formatTime(cal) + " (1h from now)";
        }

        if (task.isEmpty()) task = "Reminder";

        // Save to DB
        Reminder reminder = new Reminder(0, task, triggerAt, false);
        long id = dbHelper.insertReminder(reminder);

        // Schedule notification
        Intent reminderIntent = new Intent(context, ReminderReceiver.class);
        reminderIntent.setAction("com.quiko.app.REMINDER_TRIGGER");
        reminderIntent.putExtra("task", task);
        reminderIntent.putExtra("id", (int) id);

        PendingIntent pi = PendingIntent.getBroadcast(context, (int) id, reminderIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } else {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            }
        } catch (SecurityException e) {
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        }

        speak("Reminder set: " + task + " at " + timeDisplay);
        return "🔔 Reminder: \"" + task + "\" at " + timeDisplay;
    }

    // ─────────────────────────────────────────────────────────────────────
    // TIME
    // ─────────────────────────────────────────────────────────────────────
    private String tellTime() {
        Calendar now = Calendar.getInstance();
        String timeStr = String.format(Locale.US, "%d:%02d %s",
                now.get(Calendar.HOUR) == 0 ? 12 : now.get(Calendar.HOUR),
                now.get(Calendar.MINUTE),
                now.get(Calendar.AM_PM) == Calendar.AM ? "AM" : "PM");
        speak("It is " + timeStr);
        return "🕐 Current time: " + timeStr;
    }

    private String help() {
        String msg = "You can say: set alarm at 7 AM, flashlight on, remind me to take medicine at 8 PM, what time is it, or cancel alarm.";
        speak(msg);
        return "📋 Commands:\n• Set alarm at 7 AM\n• Alarm in 30 minutes\n• Flashlight on / off\n• Remind me to [task] at [time]\n• Cancel alarm\n• What time is it";
    }

    // ─────────────────────────────────────────────────────────────────────
    // Time Parsing  –  handles many natural language formats
    // ─────────────────────────────────────────────────────────────────────
    private Calendar parseTime(String text) {
        text = text.toLowerCase(Locale.US);

        // "in X minutes/hours"
        Pattern inPattern = Pattern.compile("in\\s+(\\w+)\\s+(minute|minutes|min|hour|hours|hr)");
        Matcher m = inPattern.matcher(text);
        if (m.find()) {
            int amount = parseNumber(m.group(1));
            if (amount > 0) {
                Calendar cal = Calendar.getInstance();
                if (m.group(2).startsWith("h")) {
                    cal.add(Calendar.HOUR_OF_DAY, amount);
                } else {
                    cal.add(Calendar.MINUTE, amount);
                }
                cal.set(Calendar.SECOND, 0);
                return cal;
            }
        }

        // "at 7:30 AM/PM" or "at 7 AM"
        Pattern atPattern = Pattern.compile(
                "(?:at\\s+)?(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm|a\\.m|p\\.m)");
        m = atPattern.matcher(text);
        if (m.find()) {
            int hour = Integer.parseInt(m.group(1));
            int minute = m.group(2) != null ? Integer.parseInt(m.group(2)) : 0;
            boolean isPm = m.group(3).startsWith("p");
            if (isPm && hour != 12) hour += 12;
            if (!isPm && hour == 12) hour = 0;
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY, hour);
            cal.set(Calendar.MINUTE, minute);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            return cal;
        }

        // "at 14:30" (24-hour)
        Pattern militaryPattern = Pattern.compile("(?:at\\s+)?(\\d{1,2}):(\\d{2})");
        m = militaryPattern.matcher(text);
        if (m.find()) {
            int hour = Integer.parseInt(m.group(1));
            int minute = Integer.parseInt(m.group(2));
            if (hour <= 23 && minute <= 59) {
                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.HOUR_OF_DAY, hour);
                cal.set(Calendar.MINUTE, minute);
                cal.set(Calendar.SECOND, 0);
                cal.set(Calendar.MILLISECOND, 0);
                return cal;
            }
        }

        // "at seven thirty" word-based
        Pattern wordTime = Pattern.compile(
                "(?:at\\s+)(\\w+)(?:\\s+(\\w+))?\\s*(am|pm|a\\.m|p\\.m)?");
        m = wordTime.matcher(text);
        if (m.find() && NUMBER_WORDS.containsKey(m.group(1))) {
            int hour = NUMBER_WORDS.get(m.group(1));
            int minute = 0;
            if (m.group(2) != null && NUMBER_WORDS.containsKey(m.group(2))) {
                minute = NUMBER_WORDS.get(m.group(2));
            }
            boolean isPm = m.group(3) != null && m.group(3).startsWith("p");
            if (isPm && hour != 12) hour += 12;
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY, hour);
            cal.set(Calendar.MINUTE, minute);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            return cal;
        }

        return null;
    }

    private int parseNumber(String word) {
        try {
            return Integer.parseInt(word);
        } catch (NumberFormatException e) {
            Integer v = NUMBER_WORDS.get(word.toLowerCase());
            return v != null ? v : -1;
        }
    }

    private boolean hasTimeContext(String cmd) {
        return cmd.matches(".*\\d+.*") ||
                cmd.contains("am") || cmd.contains("pm") ||
                cmd.contains("in ") || cmd.contains("at ");
    }

    private String formatTime(Calendar cal) {
        int h = cal.get(Calendar.HOUR);
        if (h == 0) h = 12;
        int m = cal.get(Calendar.MINUTE);
        String ampm = cal.get(Calendar.AM_PM) == Calendar.AM ? "AM" : "PM";
        return String.format(Locale.US, "%d:%02d %s", h, m, ampm);
    }

    // ─────────────────────────────────────────────────────────────────────
    // TTS helper
    // ─────────────────────────────────────────────────────────────────────
    private void speak(String text) {
        if (tts != null) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "quiko_tts");
        }
    }
}

package com.quiko.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Vibrator;
import android.os.VibrationEffect;

import androidx.core.app.NotificationCompat;

public class AlarmReceiver extends BroadcastReceiver {

    private static final String CHANNEL_ID = "quiko_alarm";

    @Override
    public void onReceive(Context context, Intent intent) {
        String label = intent.getStringExtra("label");
        String time  = intent.getStringExtra("time");
        if (label == null) label = "Quiko Alarm";
        if (time  == null) time  = "Now";

        createChannel(context);
        showAlarmNotification(context, label, time);
        playAlarmSound(context);
        vibrate(context);
    }

    private void createChannel(Context context) {
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "Quiko Alarms", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Alarm notifications");
        ch.enableVibration(true);
        NotificationManager nm = context.getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(ch);
    }

    private void showAlarmNotification(Context context, String label, String time) {
        Intent dismiss = new Intent(context, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(context, 0, dismiss,
                PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_quiko)
                .setContentTitle("⏰ " + label)
                .setContentText("Set for " + time)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setFullScreenIntent(pi, true)
                .setAutoCancel(true)
                .setContentIntent(pi);

        NotificationManager nm = context.getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(2000, builder.build());
    }

    private void playAlarmSound(Context context) {
        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            android.media.Ringtone r = RingtoneManager.getRingtone(context, uri);
            if (r != null) r.play();
        } catch (Exception e) { /* ignored */ }
    }

    private void vibrate(Context context) {
        Vibrator v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if (v == null) return;
        long[] pattern = {0, 500, 200, 500, 200, 500};
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createWaveform(pattern, -1));
        } else {
            v.vibrate(pattern, -1);
        }
    }
}

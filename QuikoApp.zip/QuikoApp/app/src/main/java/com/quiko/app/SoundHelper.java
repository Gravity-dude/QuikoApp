package com.quiko.app;

import android.content.Context;
import android.media.AudioManager;
import android.media.ToneGenerator;

public class SoundHelper {
    public static void playActivationBeep(Context context) {
        try {
            ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80);
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 150);
        } catch (Exception ignored) {}
    }
}

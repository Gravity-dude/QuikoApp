package com.quiko.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME    = "quiko.db";
    private static final int    DB_VERSION = 1;

    // Reminders table
    static final String TABLE  = "reminders";
    static final String COL_ID   = "id";
    static final String COL_TASK = "task";
    static final String COL_TIME = "trigger_time";
    static final String COL_DONE = "done";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " (" +
                COL_ID   + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_TASK + " TEXT NOT NULL, " +
                COL_TIME + " INTEGER NOT NULL, " +
                COL_DONE + " INTEGER DEFAULT 0" +
                ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    public long insertReminder(Reminder r) {
        ContentValues cv = new ContentValues();
        cv.put(COL_TASK, r.task);
        cv.put(COL_TIME, r.triggerTimeMs);
        cv.put(COL_DONE, r.done ? 1 : 0);
        return getWritableDatabase().insert(TABLE, null, cv);
    }

    public List<Reminder> getAllReminders() {
        List<Reminder> list = new ArrayList<>();
        Cursor c = getReadableDatabase()
                .query(TABLE, null, null, null, null, null, COL_TIME + " ASC");
        if (c.moveToFirst()) {
            do {
                list.add(new Reminder(
                        c.getLong(c.getColumnIndexOrThrow(COL_ID)),
                        c.getString(c.getColumnIndexOrThrow(COL_TASK)),
                        c.getLong(c.getColumnIndexOrThrow(COL_TIME)),
                        c.getInt(c.getColumnIndexOrThrow(COL_DONE)) == 1
                ));
            } while (c.moveToNext());
        }
        c.close();
        return list;
    }

    public void markReminderDone(long id) {
        ContentValues cv = new ContentValues();
        cv.put(COL_DONE, 1);
        getWritableDatabase().update(TABLE, cv, COL_ID + "=?",
                new String[]{String.valueOf(id)});
    }

    public void deleteReminder(long id) {
        getWritableDatabase().delete(TABLE, COL_ID + "=?",
                new String[]{String.valueOf(id)});
    }

    public void deleteAllReminders() {
        getWritableDatabase().delete(TABLE, null, null);
    }
}
